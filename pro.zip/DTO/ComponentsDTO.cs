﻿    namespace HeadlessCMS.DTO
{
    public class ComponentsDTO
    {
        public int id { get; set; }
        public int pageId { get; set; }

        public string Name { get; set; }
    }
}

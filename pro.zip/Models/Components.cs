﻿    namespace HeadlessCMS.Models
{
    public class Components
    {
        public int id { get; set; }
        public int pageId { get; set; }

        public string Name { get; set; }
    }
}
